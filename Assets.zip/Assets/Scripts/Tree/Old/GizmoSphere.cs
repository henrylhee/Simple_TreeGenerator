using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GizmoSphere
{
    public Vector3 position;
    public float radius;
    public Color color;

}
