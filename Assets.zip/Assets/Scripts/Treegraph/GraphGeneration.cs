using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System;
using System.Linq;
using Random = UnityEngine.Random;
//using Unity.Burst.CompilerServices;
using static UnityEditor.PlayerSettings;
using System.Security.Cryptography;


namespace Gen
{
    public class GraphGeneration : EditorWindow
    {
        //global values
        public static float phyllotaxis = 120;
        public static float branchingAngle = 80;
        public static float startThickness = 1;
        public static Vector3 startPosition = new Vector3(0, 0, 0);
        public static Vector3 startDirection = new Vector3(0, 1, 0);
        public static float thicknessSplit = 0.7f;
        public static float thicknessToSegmentLength = 0.1f;

        public static float terminalPerceptionAngle;
        public static float randomGrowthConeAngle = 15;

        public static float splitChance = 0.1f;
        public static float splitChanceIncreasePerSegment = 0.01f;
        public static float lastSegmentsWithoutSplitChance = 5;
        public static float firstSegmentsWithoutSplitChance = 5;

        public static float maxSegments = 10;

        public static bool visualizeGraph = true;


        //public GameObject tree;


        [MenuItem("Window/GraphGeneration")]
        public static void ShowWindow()
        {

            EditorWindow win = EditorWindow.GetWindow(typeof(GraphGeneration));
            win.titleContent = new GUIContent("GraphGeneration");
            win.minSize = new Vector2(275, 360);
        }

        private void OnGUI()
        {
            Editor e = Editor.CreateEditor(this);
            //scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition, GUIStyle.none, GUI.skin.verticalScrollbar);
            e.DrawDefaultInspector();
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("Generate Graph", GUILayout.Height(64)))
            {
                GameObject tree = new GameObject("Tree");
                tree.AddComponent<Graph>();
                tree.GetComponent<Graph>().Generate();
            }
        }
    }

    public class GizmoSphereDrawer
    {
        [DrawGizmo(GizmoType.Selected | GizmoType.Active)]
        static void DrawGizmoSphere(GizmoSphere sphere, GizmoType gizmoType)
        {
            Gizmos.color = sphere.color;
            Gizmos.DrawSphere(sphere.position, sphere.radius);
        }
    }
}
