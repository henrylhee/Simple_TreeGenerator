using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace Gen
{
    public class GlobalValues : MonoBehaviour
    {
        public static GlobalValues Instance;


        //public float phyllotaxis;
        //public float branchingAngle;
        //public float startThickness;
        //public Vector3 startPosition = new Vector3(0,0,0);
        //public Vector3 startDirection = new Vector3(0,1,0);
        //public float thicknessSplit;
        //public float thicknessToSegmentLength;

        //public float terminalPerceptionAngle;
        //public float randomGrowthConeAngle;

        //public float splitChance;
        //public float splitChanceIncreasePerSegment;
        //public float lastSegmentsWithoutSplitChance;

        //public float maxSegments;

        //public bool visualizeGraph = true;
    }
}

