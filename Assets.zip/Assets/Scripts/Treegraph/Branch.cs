using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using Random = UnityEngine.Random;

namespace Gen
{
    public class Branch
    {
        public UnityEvent<Branch> NewBranch = new UnityEvent<Branch>();

        public List<Internode> internodes = new List<Internode>();
        Bud startBud = null;
        public float thickness;
        public float segmentLength;
        public float lengthAtStart;
        public float segmentAtStart;
        public float currentLength;
        public float phyllotaxisAngle;


        public Branch(Bud startBud, float thickness, float lengthAtStart, float segmentAtStart)
        {
            this.startBud = startBud;
            this.segmentLength = thickness * GraphGeneration.thicknessToSegmentLength;
            this.thickness = thickness;
            this.lengthAtStart = lengthAtStart;
            this.segmentAtStart = segmentAtStart;
            phyllotaxisAngle = 0;

            internodes.Add(new Internode());
            internodes[0].Inititalize(startBud, segmentLength, thickness);
        }

        public void Generate()
        {
            GenerateInternode();
        }

        public void GenerateInternode()
        {
            if (internodes.Count + segmentAtStart >= GraphGeneration.maxSegments)
            {
                return;
            }
            else if (Random.Range(0, 1) < GraphGeneration.splitChance && internodes.Count > GraphGeneration.firstSegmentsWithoutSplitChance &&
                     internodes.Count + segmentAtStart <= GraphGeneration.maxSegments - GraphGeneration.lastSegmentsWithoutSplitChance)
            {
                NewBranch?.Invoke(new Branch(internodes[internodes.Count - 1].bud.GetSplitBud(segmentLength, phyllotaxisAngle), thickness*(1- GraphGeneration.thicknessSplit),
                                             lengthAtStart + internodes.Count * segmentLength, internodes.Count + segmentAtStart));
                phyllotaxisAngle += GraphGeneration.phyllotaxis;

                internodes.Add(new Internode());
                internodes[internodes.Count-1].Inititalize(internodes[internodes.Count - 2].FindNextBud(), segmentLength, thickness);

                Debug.Log("internode number: " + internodes.Count + " is generated.");
                GenerateInternode();
            }
            else
            {
                internodes.Add(new Internode());
                internodes[internodes.Count - 1].Inititalize(internodes[internodes.Count - 2].FindNextBud(), segmentLength, thickness);

                Debug.Log("internode number: " + internodes.Count + " is generated.");
                GenerateInternode();
            }
        }
    }
}

