using Gen;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;


namespace Gen
{
    public class Internode
    {
        public Bud bud;
        public float length;
        public float thickness;
        public Vector3 direction;

        public void Inititalize(Bud startBud, float length, float thickness)
        {
            bud = startBud;
            this.length = length;
        }

        public Bud FindNextBud()
        {
            return bud.GetChildBud(length);
        }
    }
}

