using System.Collections;
using System.Collections.Generic;
using TreeGen;
using Unity.VisualScripting.Antlr3.Runtime.Tree;
using UnityEditor;
using UnityEngine;
using Random = UnityEngine.Random;



namespace Gen
{
    public class Graph : MonoBehaviour
    {
        public List<Branch> branches = new List<Branch>();
        public GizmoSphereDrawer sphereDrawer = new GizmoSphereDrawer();

        public void Generate()
        {
            Debug.Log("Generate Graph");
            

            if (branches.Count == 0)
            {
                Debug.Log("Generate first branch.");

                branches.Add(new Branch(new Bud(GraphGeneration.startPosition, GraphGeneration.startDirection), GraphGeneration.startThickness, 0, 0));
                branches[0].NewBranch.AddListener(Split);
                branches[0].Generate();
            }
            else
            {
                Debug.LogError("There is already at least one existing branch!");
            }

            foreach(Branch branch in branches)
            {
                foreach(Internode internode in branch.internodes)
                {
                    if (GraphGeneration.visualizeGraph)
                    {
                        GizmoSphere sphere = new GizmoSphere();
                        sphere.position = internode.bud.position;
                        sphere.radius = internode.thickness * 0.1f;

                        GizmoSphereDrawer.DRawGizmoSphere(sphere, GizmoType.NonSelected);

                        void OnDrawGizmos()
                        {
                            Gizmos.color = Color.red;
                            Gizmos.DrawSphere(internode.bud.position, internode.thickness * 0.1f);

                            Gizmos.color = Color.yellow;
                            Gizmos.DrawLine(internode.bud.position, internode.FindNextBud().position);
                        }
                        OnDrawGizmos();
                    }
                }
            }
        }

        public void Split(Branch newBranch)
        {
            Debug.Log("-->Split occured! Generate new Branch. Branch count: " + branches.Count + 1);

            branches.Add(newBranch);
            branches[branches.Count-1].NewBranch.AddListener(Split);
            branches[branches.Count - 1].Generate();
        }

        
    }
}

