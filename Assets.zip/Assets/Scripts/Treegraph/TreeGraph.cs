using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Gen;

namespace TreeGen
{
    public class TreeGraph : Graph
    {
        





    }
}
