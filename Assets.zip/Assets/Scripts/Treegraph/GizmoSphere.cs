using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GizmoSphere : MonoBehaviour
{
    public Vector3 position;
    public float radius;
    public Color color = Color.red;;

}
